# ANF MetaBioDiv course material

This repository contains courses and practicals for the ANF MetaBioDiv.

The website of the course is here: https://anf-metabiodiv.github.io/course-material/